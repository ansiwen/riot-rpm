/*
 * skin-sdk.js
 *
 * Skins the react-sdk with the vector components
 */

var sdk = require('matrix-react-sdk');
sdk.loadSkin(require('../src/component-index'));
